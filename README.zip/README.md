# we are going to make galaga, 
# what do we need?
# must have:
# - player ship and control
# - enemy ships
# - collision detection
# - a shooting function for player and ai
# - start/gameover screens
# nice to have:
# - power ups
# - moving background
# - score/highscore
# - boss battles
# - variable difficulty
# - level select
# - friendly ai
# - multiplayer
# - game modes
# - graphics that aren't garbage
